package com.mandouniversal

import android.hardware.ConsumerIrManager

enum class Protocol(val label: String, val hint: String) {
    NEC("NEC", "Hex de 32 bits, ej. 20DF10EF"),
    NECF("NEC dir:cmd", "dirección:comando en hex, ej. 04:08 (formato de Flipper-IRDB)"),
    SAMSUNG("Samsung", "Hex de 32 bits, ej. E0E040BF"),
    SAMSF("Samsung dir:cmd", "dirección:comando en hex, ej. 07:02"),
    JVC("JVC dir:cmd", "dirección:comando en hex, ej. 03:17"),
    SONY("Sony SIRC", "dirección:comando en hex, ej. 01:15"),
    RC5("Philips RC5", "dirección:comando en hex, ej. 00:0C"),
    PRONTO("Pronto", "Códigos Pronto en hex, empiezan por 0000"),
    RAW("Raw", "Frecuencia y tiempos en µs, ej. 38000,9000,4500,560,560,...")
}

class IrPattern(val freq: Int, val pattern: IntArray)

object IrEngine {

    /** Devuelve null si todo va bien, o un mensaje de error. */
    fun send(ir: ConsumerIrManager?, b: IrButton): String? {
        if (ir == null || !ir.hasIrEmitter()) return "Este móvil no tiene emisor infrarrojo"
        val p = build(b.protocol, b.code) ?: return "Código no válido para ${b.protocol.label}"
        return try {
            ir.transmit(p.freq, p.pattern)
            null
        } catch (e: Exception) {
            "Error al enviar: ${e.message}"
        }
    }

    fun build(p: Protocol, code: String): IrPattern? {
        return try {
            when (p) {
                Protocol.NEC -> necLike(code, 9000, 4500)
                Protocol.NECF -> necf(code)
                Protocol.SAMSUNG -> necLike(code, 4500, 4500)
                Protocol.SAMSF -> samsf(code)
                Protocol.JVC -> jvc(code)
                Protocol.SONY -> sony(code)
                Protocol.RC5 -> rc5(code)
                Protocol.PRONTO -> pronto(code)
                Protocol.RAW -> raw(code)
            }
        } catch (e: Exception) {
            null
        }
    }

    fun rev8(x: Int): Int {
        var r = 0
        for (i in 0 until 8) {
            if (((x shr i) and 1) == 1) r = r or (1 shl (7 - i))
        }
        return r
    }

    fun necHex(addr: Int, cmd: Int): String {
        val a = addr and 255
        val c = cmd and 255
        return String.format(
            "%02X%02X%02X%02X",
            rev8(a), rev8(a.inv() and 255), rev8(c), rev8(c.inv() and 255)
        )
    }

    fun samsungHex(addr: Int, cmd: Int): String {
        val a = addr and 255
        val c = cmd and 255
        return String.format(
            "%02X%02X%02X%02X",
            rev8(a), rev8(a), rev8(c), rev8(c.inv() and 255)
        )
    }

    private fun samsf(code: String): IrPattern? {
        val p = parts(code)
        if (p.size < 2) return null
        return necLike(samsungHex(p[0].toInt(16), p[1].toInt(16)), 4500, 4500)
    }

    private fun jvc(code: String): IrPattern? {
        val p = parts(code)
        if (p.size < 2) return null
        val a = p[0].toInt(16) and 255
        val c = p[1].toInt(16) and 255
        val out = ArrayList<Int>()
        out.add(8400)
        out.add(4200)
        for (i in 0 until 8) {
            out.add(525)
            out.add(if (((a shr i) and 1) == 1) 1575 else 525)
        }
        for (i in 0 until 8) {
            out.add(525)
            out.add(if (((c shr i) and 1) == 1) 1575 else 525)
        }
        out.add(525)
        return IrPattern(38000, out.toIntArray())
    }

    private fun necf(code: String): IrPattern? {
        val p = parts(code)
        if (p.size < 2) return null
        return necLike(necHex(p[0].toInt(16), p[1].toInt(16)), 9000, 4500)
    }

    private fun necLike(code: String, h1: Int, h2: Int): IrPattern? {
        val clean = code.trim().removePrefix("0x").removePrefix("0X").replace(" ", "")
        if (clean.isEmpty() || clean.length > 8) return null
        val v = clean.toLong(16)
        val out = ArrayList<Int>()
        out.add(h1)
        out.add(h2)
        for (i in 31 downTo 0) {
            out.add(560)
            out.add(if (((v shr i) and 1L) == 1L) 1690 else 560)
        }
        out.add(560)
        return IrPattern(38000, out.toIntArray())
    }

    private fun parts(code: String): List<String> =
        code.split(":", ",", " ", "-").filter { it.isNotBlank() }

    private fun sony(code: String): IrPattern? {
        val p = parts(code)
        if (p.size < 2) return null
        val addr = p[0].toInt(16)
        val cmd = p[1].toInt(16)
        if (cmd > 127 || addr > 255) return null
        val addrBits = if (addr < 32) 5 else 8
        val frame = ArrayList<Int>()
        frame.add(2400)
        frame.add(600)
        for (i in 0 until 7) {
            frame.add(if (((cmd shr i) and 1) == 1) 1200 else 600)
            frame.add(600)
        }
        for (i in 0 until addrBits) {
            frame.add(if (((addr shr i) and 1) == 1) 1200 else 600)
            frame.add(600)
        }
        val total = frame.sum()
        val out = ArrayList<Int>()
        for (r in 0 until 3) {
            val copy = ArrayList<Int>(frame)
            if (r < 2) {
                copy[copy.size - 1] = copy[copy.size - 1] + (45000 - total)
            }
            out.addAll(copy)
        }
        return IrPattern(40000, out.toIntArray())
    }

    private fun rc5(code: String): IrPattern? {
        val p = parts(code)
        if (p.size < 2) return null
        val a = p[0].toInt(16) and 31
        val c = p[1].toInt(16) and 127
        val bits = ArrayList<Int>()
        bits.add(1)
        bits.add(if (c < 64) 1 else 0)
        bits.add(0)
        for (i in 4 downTo 0) bits.add((a shr i) and 1)
        for (i in 5 downTo 0) bits.add((c shr i) and 1)
        val half = ArrayList<Boolean>()
        for (b in bits) {
            if (b == 1) {
                half.add(false)
                half.add(true)
            } else {
                half.add(true)
                half.add(false)
            }
        }
        val out = ArrayList<Int>()
        var start = 0
        if (!half[0]) start = 1
        var cur = true
        var len = 0
        for (i in start until half.size) {
            if (half[i] == cur) {
                len += 889
            } else {
                out.add(len)
                cur = half[i]
                len = 889
            }
        }
        out.add(len)
        return IrPattern(36000, out.toIntArray())
    }

    private fun pronto(code: String): IrPattern? {
        val w = code.trim().split(Regex("\\s+")).map { it.toInt(16) }
        if (w.size < 6 || w[0] != 0) return null
        val period = w[1] * 0.241246
        if (period <= 0.0) return null
        val freq = (1_000_000 / period).toInt()
        val pairs = if (w[2] > 0) w[2] else w[3]
        val n = pairs * 2
        if (n == 0 || w.size < 4 + n) return null
        val out = IntArray(n) { (w[4 + it] * period).toInt().coerceAtLeast(1) }
        return IrPattern(freq, out)
    }

    private fun raw(code: String): IrPattern? {
        val nums = Regex("\\d+").findAll(code).map { it.value.toInt() }.toList()
        if (nums.size < 3) return null
        val hasFreq = nums[0] in 20000..60000
        val freq = if (hasFreq) nums[0] else 38000
        val d = if (hasFreq) nums.drop(1) else nums
        if (d.size < 2) return null
        return IrPattern(freq, d.toIntArray())
    }
}
