package com.mandouniversal

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class IrButton(val label: String, val protocol: Protocol, val code: String)

data class Remote(
    val id: String,
    val name: String,
    val emoji: String,
    val buttons: List<IrButton>
)

fun newId(): String = UUID.randomUUID().toString()

class Store(context: Context) {
    private val prefs = context.getSharedPreferences("mando", Context.MODE_PRIVATE)

    fun load(): List<Remote> {
        val raw = prefs.getString("remotes", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val bs = o.getJSONArray("buttons")
                val buttons = (0 until bs.length()).map { j ->
                    val b = bs.getJSONObject(j)
                    val proto = try {
                        Protocol.valueOf(b.getString("protocol"))
                    } catch (e: Exception) {
                        Protocol.NEC
                    }
                    IrButton(b.getString("label"), proto, b.getString("code"))
                }
                Remote(o.getString("id"), o.getString("name"), o.optString("emoji", "🎛️"), buttons)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(list: List<Remote>) {
        val arr = JSONArray()
        for (r in list) {
            val o = JSONObject()
            o.put("id", r.id)
            o.put("name", r.name)
            o.put("emoji", r.emoji)
            val bs = JSONArray()
            for (b in r.buttons) {
                val jb = JSONObject()
                jb.put("label", b.label)
                jb.put("protocol", b.protocol.name)
                jb.put("code", b.code)
                bs.put(jb)
            }
            o.put("buttons", bs)
            arr.put(o)
        }
        prefs.edit().putString("remotes", arr.toString()).apply()
    }
}

object Presets {
    private fun nec(l: String, c: String) = IrButton(l, Protocol.NEC, c)
    private fun sam(l: String, c: String) = IrButton(l, Protocol.SAMSUNG, c)
    private fun sony(l: String, c: String) = IrButton(l, Protocol.SONY, c)

    val templates: List<Remote> = listOf(
        Remote("", "Mando vacío", "🎛️", emptyList()),
        Remote("", "TV LG", "📺", listOf(
            nec("⏻", "20DF10EF"), nec("Vol +", "20DF40BF"), nec("Vol -", "20DFC03F"),
            nec("Silencio", "20DF906F"), nec("Canal +", "20DF00FF"), nec("Canal -", "20DF807F"),
            nec("Entrada", "20DFD02F"), nec("▲", "20DF02FD"), nec("OK", "20DF22DD"),
            nec("◀", "20DFE01F"), nec("▼", "20DF827D"), nec("▶", "20DF609F"),
            nec("Atrás", "20DF14EB")
        )),
        Remote("", "TV Samsung", "📺", listOf(
            sam("⏻", "E0E040BF"), sam("Vol +", "E0E0E01F"), sam("Vol -", "E0E0D02F"),
            sam("Silencio", "E0E0F00F"), sam("Canal +", "E0E048B7"), sam("Canal -", "E0E008F7"),
            sam("Fuente", "E0E0807F"), sam("▲", "E0E006F9"), sam("OK", "E0E016E9"),
            sam("◀", "E0E0A659"), sam("▼", "E0E08679"), sam("▶", "E0E046B9"),
            sam("Menú", "E0E058A7"), sam("Volver", "E0E01AE5")
        )),
        Remote("", "TV Sony", "📺", listOf(
            sony("⏻", "01:15"), sony("Vol +", "01:12"), sony("Vol -", "01:13"),
            sony("Silencio", "01:14"), sony("Canal +", "01:10"), sony("Canal -", "01:11"),
            sony("Entrada", "01:25"), sony("▲", "01:74"), sony("OK", "01:65"),
            sony("◀", "01:34"), sony("▼", "01:75"), sony("▶", "01:33")
        )),
        Remote("", "Tira LED (24 teclas)", "💡", listOf(
            nec("Encender", "00F7C03F"), nec("Apagar", "00F740BF"),
            nec("Brillo +", "00F700FF"), nec("Brillo -", "00F7807F"),
            nec("Rojo", "00F720DF"), nec("Verde", "00F7A05F"),
            nec("Azul", "00F7609F"), nec("Blanco", "00F7E01F")
        ))
    )

    /** Códigos de encendido habituales para probar uno tras otro. */
    val powerCandidates: List<IrButton> = listOf(
        IrButton("LG", Protocol.NEC, "20DF10EF"),
        IrButton("Samsung", Protocol.SAMSUNG, "E0E040BF"),
        IrButton("Sony", Protocol.SONY, "01:15"),
        IrButton("Philips (RC5)", Protocol.RC5, "00:0C"),
        IrButton("Tira LED 24 teclas", Protocol.NEC, "00F7C03F"),
        IrButton("Tira LED 44 teclas", Protocol.NEC, "00FF02FD")
    )
}
