@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.mandouniversal

import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

sealed class Screen {
    object Home : Screen()
    object Templates : Screen()
    object Lab : Screen()
    data class Open(val id: String) : Screen()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ir = getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
        val store = Store(this)
        setContent {
            AppTheme { App(ir, store) }
        }
    }
}

fun toast(ctx: Context, msg: String) {
    Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
}

fun fire(ctx: Context, ir: ConsumerIrManager?, b: IrButton) {
    val err = IrEngine.send(ir, b)
    if (err != null) toast(ctx, err)
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFFFB300),
            onPrimary = Color.Black,
            secondary = Color(0xFF26C6DA),
            background = Color(0xFF0E1116),
            surface = Color(0xFF181C23),
            onBackground = Color(0xFFECEFF4),
            onSurface = Color(0xFFECEFF4),
            surfaceVariant = Color(0xFF232933),
            onSurfaceVariant = Color(0xFFB8C0CC)
        ),
        content = content
    )
}

@Composable
fun App(ir: ConsumerIrManager?, store: Store) {
    var remotes by remember { mutableStateOf(store.load()) }
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    val hasIr = ir != null && ir.hasIrEmitter()

    fun persist(list: List<Remote>) {
        remotes = list
        store.save(list)
    }

    BackHandler(enabled = screen != Screen.Home) { screen = Screen.Home }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(Modifier.fillMaxSize().systemBarsPadding()) {
            when (val s = screen) {
                is Screen.Home -> HomeScreen(
                    remotes = remotes,
                    hasIr = hasIr,
                    onOpen = { screen = Screen.Open(it.id) },
                    onNew = { screen = Screen.Templates },
                    onLab = { screen = Screen.Lab }
                )
                is Screen.Templates -> TemplatesScreen(
                    onBack = { screen = Screen.Home },
                    onCreate = { r ->
                        persist(remotes + r)
                        screen = Screen.Open(r.id)
                    }
                )
                is Screen.Lab -> LabScreen(
                    ir = ir,
                    onBack = { screen = Screen.Home },
                    onCreate = { r ->
                        persist(remotes + r)
                        screen = Screen.Open(r.id)
                    }
                )
                is Screen.Open -> {
                    val r = remotes.firstOrNull { it.id == s.id }
                    if (r == null) {
                        LaunchedEffect(Unit) { screen = Screen.Home }
                    } else {
                        RemoteScreen(
                            remote = r,
                            ir = ir,
                            onUpdate = { nr -> persist(remotes.map { if (it.id == nr.id) nr else it }) },
                            onDelete = {
                                persist(remotes.filter { it.id != r.id })
                                screen = Screen.Home
                            },
                            onBack = { screen = Screen.Home }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    remotes: List<Remote>,
    hasIr: Boolean,
    onOpen: (Remote) -> Unit,
    onNew: () -> Unit,
    onLab: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            "Mando Universal",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            "Controla todo lo que use infrarrojos",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))
        if (!hasIr) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF4A2A12)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "⚠️ No se detecta emisor infrarrojo en este móvil. Los botones no enviarán nada.",
                    modifier = Modifier.padding(12.dp)
                )
            }
            Spacer(Modifier.height(12.dp))
        }
        if (remotes.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    "Aún no tienes mandos.\nPulsa «Nuevo mando» para empezar.",
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(Modifier.weight(1f)) {
                items(remotes, key = { it.id }) { r ->
                    Card(
                        onClick = { onOpen(r) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(r.emoji, fontSize = 32.sp)
                            Spacer(Modifier.width(14.dp))
                            Column {
                                Text(r.name, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "${r.buttons.size} botones",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onNew, modifier = Modifier.weight(1f)) { Text("＋ Nuevo mando") }
            OutlinedButton(onClick = onLab, modifier = Modifier.weight(1f)) { Text("🔬 Laboratorio") }
        }
    }
}

@Composable
fun TemplatesScreen(onBack: () -> Unit, onCreate: (Remote) -> Unit) {
    var chosen by remember { mutableStateOf<Remote?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TextButton(onClick = onBack) { Text("‹ Atrás") }
        Text("Elige un punto de partida", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(
            "Son códigos habituales de cada marca y pueden variar según el modelo. " +
                "Si un botón no responde, mantenlo pulsado para editarlo.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 8.dp)
        )
        LazyColumn(Modifier.weight(1f)) {
            items(Presets.templates) { t ->
                Card(
                    onClick = { chosen = t },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(t.emoji, fontSize = 28.sp)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(t.name, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                            Text(
                                if (t.buttons.isEmpty()) "Sin botones, tú los creas" else "${t.buttons.size} botones",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
    val c = chosen
    if (c != null) {
        NameDialog(
            title = "Nombre del mando",
            initial = c.name,
            onOk = { n -> onCreate(c.copy(id = newId(), name = n)) },
            onDismiss = { chosen = null }
        )
    }
}

@Composable
fun IrKey(b: IrButton, onClick: () -> Unit, onLong: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    Box(
        modifier = Modifier
            .aspectRatio(1.3f)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .combinedClickable(
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onClick()
                },
                onLongClick = onLong
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            b.label,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(6.dp)
        )
    }
}

@Composable
fun RemoteScreen(
    remote: Remote,
    ir: ConsumerIrManager?,
    onUpdate: (Remote) -> Unit,
    onDelete: () -> Unit,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    var editing by remember { mutableStateOf<Int?>(null) }
    var renaming by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Atrás") }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { renaming = true }) { Text("✏️") }
            TextButton(onClick = { confirmDelete = true }) { Text("🗑️") }
        }
        Text(
            "${remote.emoji} ${remote.name}",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
        Text(
            "Toca para enviar · mantén pulsado para editar",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 8.dp)
        )
        Spacer(Modifier.height(12.dp))
        if (remote.buttons.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("Sin botones todavía", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(remote.buttons) { idx, b ->
                    IrKey(b, onClick = { fire(ctx, ir, b) }, onLong = { editing = idx })
                }
            }
        }
        Button(
            onClick = { editing = -1 },
            modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
        ) { Text("＋ Añadir botón") }
    }

    val e = editing
    if (e != null) {
        val initial = remote.buttons.getOrNull(e)
        val doDelete: () -> Unit = {
            onUpdate(remote.copy(buttons = remote.buttons.filterIndexed { i, _ -> i != e }))
            editing = null
        }
        val deleteAction: (() -> Unit)? = if (initial != null) doDelete else null
        ButtonEditor(
            initial = initial,
            onSave = { nb ->
                val list = remote.buttons.toMutableList()
                if (initial == null) list.add(nb) else list[e] = nb
                onUpdate(remote.copy(buttons = list))
                editing = null
            },
            onDelete = deleteAction,
            onTest = { fire(ctx, ir, it) },
            onDismiss = { editing = null }
        )
    }
    if (renaming) {
        NameDialog(
            title = "Renombrar mando",
            initial = remote.name,
            onOk = { n ->
                onUpdate(remote.copy(name = n))
                renaming = false
            },
            onDismiss = { renaming = false }
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("¿Borrar este mando?") },
            text = { Text("Se borrarán también todos sus botones.") },
            confirmButton = { TextButton(onClick = onDelete) { Text("Borrar") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
fun ProtocolPicker(selected: Protocol, onSelect: (Protocol) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState())) {
        Protocol.values().forEach { p ->
            FilterChip(
                selected = p == selected,
                onClick = { onSelect(p) },
                label = { Text(p.label) }
            )
            Spacer(Modifier.width(6.dp))
        }
    }
    Text(
        selected.hint,
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(vertical = 6.dp)
    )
}

@Composable
fun ButtonEditor(
    initial: IrButton?,
    onSave: (IrButton) -> Unit,
    onDelete: (() -> Unit)?,
    onTest: (IrButton) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(initial?.label ?: "") }
    var proto by remember { mutableStateOf(initial?.protocol ?: Protocol.NEC) }
    var code by remember { mutableStateOf(initial?.code ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Nuevo botón" else "Editar botón") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nombre del botón") },
                    singleLine = true
                )
                Spacer(Modifier.height(10.dp))
                ProtocolPicker(proto) { proto = it }
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it },
                    label = { Text("Código") }
                )
                TextButton(onClick = { onTest(IrButton(name, proto, code.trim())) }) {
                    Text("📡 Probar")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isNotBlank() && code.isNotBlank()) {
                    onSave(IrButton(name.trim(), proto, code.trim()))
                }
            }) { Text("Guardar") }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) { Text("Borrar") }
                }
                TextButton(onClick = onDismiss) { Text("Cancelar") }
            }
        }
    )
}

@Composable
fun NameDialog(title: String, initial: String, onOk: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true
            )
        },
        confirmButton = {
            TextButton(onClick = { if (text.isNotBlank()) onOk(text.trim()) }) { Text("Aceptar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun LabScreen(ir: ConsumerIrManager?, onBack: () -> Unit, onCreate: (Remote) -> Unit) {
    val ctx = LocalContext.current
    val cand = Presets.powerCandidates
    var i by remember { mutableStateOf(0) }
    var proto by remember { mutableStateOf(Protocol.NEC) }
    var code by remember { mutableStateOf("") }
    val cur = cand[i]
    var group by remember { mutableStateOf("Todos") }
    val sweep = Presets.sweepGroups[group] ?: Presets.sweepGroups.getValue("Todos")
    var sIdx by remember { mutableStateOf(0) }
    var running by remember { mutableStateOf(false) }

    LaunchedEffect(running) {
        if (running) {
            while (true) {
                IrEngine.send(ir, sweep[sIdx])
                delay(300)
                if (sIdx >= sweep.size - 1) break
                sIdx++
            }
            running = false
        }
    }

    Column(
        Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())
    ) {
        TextButton(onClick = onBack) { Text("‹ Atrás") }
        Text("Laboratorio", fontSize = 22.sp, fontWeight = FontWeight.Bold)

        Spacer(Modifier.height(16.dp))
        Text("🔎 Buscar el código de encendido", fontWeight = FontWeight.SemiBold)
        Text(
            "Apunta al aparato y ve probando marcas hasta que reaccione.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(10.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${i + 1} de ${cand.size}", fontSize = 12.sp)
                Text(cur.label, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(
                    "${cur.protocol.label} · ${cur.code}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                Button(onClick = { fire(ctx, ir, cur) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Enviar encendido")
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { i = (i - 1 + cand.size) % cand.size }) { Text("◀ Anterior") }
                    TextButton(onClick = { i = (i + 1) % cand.size }) { Text("Siguiente ▶") }
                }
                OutlinedButton(
                    onClick = {
                        onCreate(Remote(newId(), "Mando ${cur.label}", "🎛️", listOf(cur.copy(label = "Power"))))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Funciona: crear mando") }
            }
        }

        Spacer(Modifier.height(24.dp))
        Text("🤖 Barrido automático (no sé la marca)", fontWeight = FontWeight.SemiBold)
        Text(
            "Prueba miles de códigos de encendido seguidos de muchas marcas. Apunta al aparato y pulsa «¡Reaccionó!» en cuanto se apague o se encienda.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(10.dp))
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            Presets.sweepGroups.keys.forEach { g ->
                FilterChip(
                    selected = g == group,
                    onClick = {
                        running = false
                        sIdx = 0
                        group = g
                    },
                    label = { Text(g) }
                )
                Spacer(Modifier.width(6.dp))
            }
        }
        Text(
            "${sweep.size} códigos · unos ${sweep.size * 3 / 600} min en total",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 6.dp)
        )
        val sw = sweep[sIdx]
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${sIdx + 1} de ${sweep.size}", fontSize = 12.sp)
                Text(sw.label, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                if (running) {
                    Button(
                        onClick = {
                            running = false
                            sIdx = maxOf(0, sIdx - 2)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("✋ ¡Reaccionó!") }
                } else {
                    Button(onClick = { running = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (sIdx == 0) "▶ Empezar barrido" else "▶ Continuar barrido")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = { if (sIdx > 0) sIdx-- }) { Text("◀") }
                        TextButton(onClick = { fire(ctx, ir, sw) }) { Text("Enviar este") }
                        TextButton(onClick = { if (sIdx < sweep.size - 1) sIdx++ }) { Text("▶") }
                    }
                    OutlinedButton(
                        onClick = {
                            onCreate(Remote(newId(), "Mando nuevo", "📺", listOf(sw.copy(label = "Power"))))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Este funciona: crear mando") }
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        Text("🧪 Probar un código a mano", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        ProtocolPicker(proto) { proto = it }
        OutlinedTextField(
            value = code,
            onValueChange = { code = it },
            label = { Text("Código") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { fire(ctx, ir, IrButton("prueba", proto, code.trim())) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("📡 Enviar") }
        OutlinedButton(
            onClick = {
                if (code.isNotBlank()) {
                    onCreate(Remote(newId(), "Mando nuevo", "🎛️", listOf(IrButton("Botón 1", proto, code.trim()))))
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Crear mando con este código") }
    }
}
